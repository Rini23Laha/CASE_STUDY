USE Trivago; ----- Trivago database created

---------Step 1 left joins will be used to acive the clicks and bookings and when we divide the sum of number of bookings and number of clicks we 
-------------will achive our booking conversion
SELECT
    h.country,
    SUM(b.number_bookings) / SUM(c.number_clicks) AS booking_conversion
FROM
    trivago.hotels h
LEFT JOIN
    trivago.clicks c ON h.hotel_id = c.hotel_id
LEFT JOIN
    trivago.bookings b ON h.hotel_id = b.hotel_id
GROUP BY
    h.country
ORDER BY
    h.country;