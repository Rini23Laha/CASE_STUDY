USE Trivago;-- created a database

WITH RECURSIVE DateRange AS (
    SELECT MIN(check_in_date) AS min_date, MAX(check_out_date) AS max_date
    FROM reservations
    UNION ALL
    SELECT DATE_ADD(min_date, INTERVAL 1 DAY), max_date
    FROM DateRange
    WHERE DATE_ADD(min_date, INTERVAL 1 DAY) < max_date
),                                                        ----Step 1  ------------- If we do select* from Daterange it will give you min and max date for the booking considering the max date as fix 17th we can eleminate this max date in next steps and min_date will be used further

OccupancyPerDay AS (
    SELECT 
        dr.min_date AS date,
        COUNT(r.reservation_id) AS rooms_needed
    FROM 
        DateRange dr
    JOIN 
        reservations r ON dr.min_date >= r.check_in_date AND dr.min_date < r.check_out_date
    GROUP BY 
        dr.min_date
),               ----Step 2 ------- If we  do select * from occupancyperday it will give you list of dates with number of rooms required per day hence per day count will be achieved 

RoomsPerWeek AS (
    SELECT 
        DATE_FORMAT(date, '%Y-%u') AS week,
        count(rooms_needed) as total_rooms
    FROM 
        OccupancyPerDay   group by week

)-------Step 3----------------- If we do select * from RoomsPerWeek it will provide rooms required per week dateformat is used to cummalative dates and consider it as week and counting total number of rooms required
SELECT 
    week, ceil(total_rooms/2) as room_needed
    
FROM 
    RoomsPerWeek
ORDER BY 
    week; -----Step 4-----------This is the final step where we have to just divide the total number of rooms by 2 as we are considering the general case per room there will be 2 people and we will achive our output
